# # # # # # # # # # # # # # # # # # # # # import ijson

# # # # # # # # # # # # # # # # # # # # # with open('Electronics_5.json', 'r') as file:
# # # # # # # # # # # # # # # # # # # # #     # Parse the JSON objects one by one
# # # # # # # # # # # # # # # # # # # # #     parser = ijson.items(file)
# # # # # # # # # # # # # # # # # # # # #     for item in parser:
# # # # # # # # # # # # # # # # # # # # #         # Process each item as needed
# # # # # # # # # # # # # # # # # # # # #         print(item)

# # # # # # # # # # # # # # # # # # # # import json

# # # # # # # # # # # # # # # # # # # # # Variable for all the headphones
# # # # # # # # # # # # # # # # # # # # headphones = {}

# # # # # # # # # # # # # # # # # # # # # Variable for all reviews of headphones

# # # # # # # # # # # # # # # # # # # # headphones_review = {}

# # # # # # # # # # # # # # # # # # # # with open('meta_Electronics.json', 'r') as file:
# # # # # # # # # # # # # # # # # # # #     # while True:
# # # # # # # # # # # # # # # # # # # #     #     line = file.readline()
# # # # # # # # # # # # # # # # # # # #     #     if not line:
# # # # # # # # # # # # # # # # # # # #     #         break
# # # # # # # # # # # # # # # # # # # #     #     data = json.loads(line)
    
# # # # # # # # # # # # # # # # # # # #     line = file.readline()
# # # # # # # # # # # # # # # # # # # #     data = json.loads(line)
# # # # # # # # # # # # # # # # # # # #     for i in data:
# # # # # # # # # # # # # # # # # # # #         print(f"{i}: {data[i]} ({type(data[i])})")


# # # # # # # # # # # # # # # # # # # # print("_" * 100)


# # # # # # # # # # # # # # # # # # # # # with open('Electronics_5.json', 'r') as file:
# # # # # # # # # # # # # # # # # # # # #     # while True:
# # # # # # # # # # # # # # # # # # # # #     line = file.readline()
# # # # # # # # # # # # # # # # # # # # #     # if not line:
# # # # # # # # # # # # # # # # # # # # #     #     break
# # # # # # # # # # # # # # # # # # # # #     data = json.loads(line)
# # # # # # # # # # # # # # # # # # # # #     for i in data:
# # # # # # # # # # # # # # # # # # # # #         print(f"{i}: {data[i]} ({type(data[i])})")


# # # # # # # # # # # # # # # # # # # x = {1 : 2, 3 : 4}
# # # # # # # # # # # # # # # # # # # print(len(x))

# # # # # # # # # # # # # # # # # # import time
# # # # # # # # # # # # # # # # # # import sys


# # # # # # # # # # # # # # # # # # # i = 0
# # # # # # # # # # # # # # # # # # # while time.sleep(0.2) == None:
# # # # # # # # # # # # # # # # # # #     sys.stdout.write("Counter: %d\r" %i)
# # # # # # # # # # # # # # # # # # #     sys.stdout.flush()
# # # # # # # # # # # # # # # # # # #     i += 1

# # # # # # # # # # # # # # # # # # def hello():
# # # # # # # # # # # # # # # # # #     print('Hello')
# # # # # # # # # # # # # # # # # #     time.sleep(2)
# # # # # # # # # # # # # # # # # #     print('\rHi')

# # # # # # # # # # # # # # # # # # hello()

# # # # # # # # # # # # # # # # # import pandas as pd
# # # # # # # # # # # # # # # # # import gzip
# # # # # # # # # # # # # # # # # import json

# # # # # # # # # # # # # # # # # def parse(path):
# # # # # # # # # # # # # # # # #   g = gzip.open(path, 'rb')
# # # # # # # # # # # # # # # # #   for l in g:
# # # # # # # # # # # # # # # # #     print("loading")
# # # # # # # # # # # # # # # # #     yield json.loads(l)

# # # # # # # # # # # # # # # # # def getDF(path):
# # # # # # # # # # # # # # # # # #   i = 0
# # # # # # # # # # # # # # # # #   df = {}
# # # # # # # # # # # # # # # # #   for d in parse(path):
# # # # # # # # # # # # # # # # #     print(f"loading {i}")
# # # # # # # # # # # # # # # # #     df[i] = d
# # # # # # # # # # # # # # # # #     i += 1
# # # # # # # # # # # # # # # # #   return pd.DataFrame.from_dict(df, orient='index')

# # # # # # # # # # # # # # # # # df = getDF('Electronics_5.json.gz')
# # # # # # # # # # # # # # # # # print("done")
# # # # # # # # # # # # # # # # # print(df)
# # # # # # # # # # # # # # # # # print("printed")

# # # # # # # # # # # # # # # # # Importing pandas as pd
# # # # # # # # # # # # # # # # import pandas as pd

# # # # # # # # # # # # # # # # # Creating the first Dataframe using dictionary
# # # # # # # # # # # # # # # # df1 = pd.DataFrame({"a":[1, 2, 3, 4],
# # # # # # # # # # # # # # # #                     "b":[5, 6, 7, 8]})

# # # # # # # # # # # # # # # # # Creating the Second Dataframe using dictionary
# # # # # # # # # # # # # # # # df2 = pd.DataFrame({"a":[1, 2, 3],
# # # # # # # # # # # # # # # #                     "b":[5, 6, 7],
# # # # # # # # # # # # # # # #                     "c":[1, 5, 4]})

# # # # # # # # # # # # # # # # x = {"a" : 69, "b" : 69, "c" : 69}
# # # # # # # # # # # # # # # # df1.loc[4] = x
# # # # # # # # # # # # # # # # print(df1)
# # # # # # # # # # # # # # # # # df1 = df1.append(x)
# # # # # # # # # # # # # # # # # print(df1)

# # # # # # # # # # # # # # from time import sleep
# # # # # # # # # # # # # # # from progress.bar import Bar


# # # # # # # # # # # # # # # # with Bar('Loading', fill='#', suffix='%(percent).1f%% - %(eta)ds') as bar:
# # # # # # # # # # # # # # # with Bar("Loading", max = 500) as bar:
# # # # # # # # # # # # # # #     for i in range(101):
# # # # # # # # # # # # # # #         sleep(0.02)
# # # # # # # # # # # # # # #         bar.next()

# # # # # # # # # # # # # # # # print("screw you")

# # # # # # # # # # # # # # # # print(Bar.doc())

# # # # # # # # # # # # # # from tqdm import tqdm

# # # # # # # # # # # # # # x = tqdm(total = 6739590)
# # # # # # # # # # # # # # for i in range(6739590):
# # # # # # # # # # # # # #     # sleep(0.5)
# # # # # # # # # # # # # #     x.update()


# # # # # # # # # # # # # import pandas as pd

# # # # # # # # # # # # # data = {
# # # # # # # # # # # # #     "A": ["TeamA", "TeamB", "TeamB", "TeamC", "TeamA"],
# # # # # # # # # # # # #     "B": [50, 40, 40, 30, 50],
# # # # # # # # # # # # #     "C": [True, False, False, False, False]
# # # # # # # # # # # # # }

# # # # # # # # # # # # # df = pd.DataFrame(data)

# # # # # # # # # # # # # # df1 = df.apply(lambda x : True if x['B'] <= 40 else False, axis = 1)

# # # # # # # # # # # # # print(df)

# # # # # # # # # # # # # print(df.groupby("C").size())

# # # # # # # # # # # # import re

# # # # # # # # # # # # def remove_html_tags(text):
# # # # # # # # # # # #     # Compile the regex pattern to improve performance
# # # # # # # # # # # #     pattern = re.compile(r'<.*?>')
# # # # # # # # # # # #     return re.sub(pattern, '', text)

# # # # # # # # # # # # # Example usage:
# # # # # # # # # # # # html_text = "<p>This is <b>bold</b> text with <a href='https://example.com'>links</a>.</p>"
# # # # # # # # # # # # clean_text = remove_html_tags(html_text)
# # # # # # # # # # # # print(clean_text)

# # # # # # # # # # # from unidecode import unidecode

# # # # # # # # # # # def remove_accents(text):
# # # # # # # # # # #     return unidecode(text)

# # # # # # # # # # # # Example usage:
# # # # # # # # # # # accented_text = "Café au lait"
# # # # # # # # # # # clean_text = remove_accents(accented_text)
# # # # # # # # # # # print(clean_text)  # Output: "Cafe au lait"

# # # # # # # # # # import spacy
# # # # # # # # # # from scispacy.abbreviation import AbbreviationDetector

# # # # # # # # # # nlp = spacy.load("en_core_web_sm")
# # # # # # # # # # abbreviation_pipe = AbbreviationDetector(nlp)
# # # # # # # # # # nlp.add_pipe(abbreviation_pipe)

# # # # # # # # # # text = "StackOverflow (SO) is a question and answer site for professional and enthusiast programmers. SO rocks!"

# # # # # # # # # # def replace_acronyms(text):
# # # # # # # # # #     doc = nlp(text)
# # # # # # # # # #     altered_tokens = [tok.text for tok in doc]
# # # # # # # # # #     for abrv in doc._.abbreviations:
# # # # # # # # # #         altered_tokens[abrv.start] = str(abrv._.long_form)
# # # # # # # # # #     return " ".join(altered_tokens)

# # # # # # # # # # expanded_text = replace_acronyms(text)
# # # # # # # # # # print(expanded_text)

# # # # # # # # # # import library
# # # # # # # # # import contractions
# # # # # # # # # # contracted text
# # # # # # # # # text = '''I'll be there within 5 min. Shouldn't you be there too? 
# # # # # # # # # 		I'd love to see u there my dear. It's awesome to meet new friends.
# # # # # # # # # 		We've been waiting for this day for so long.'''

# # # # # # # # # # creating an empty list
# # # # # # # # # expanded_words = [] 
# # # # # # # # # for word in text.split():
# # # # # # # # # # using contractions.fix to expand the shortened words
# # # # # # # # #     expanded_words.append(contractions.fix(word)) 

# # # # # # # # # expanded_text = ' '.join(expanded_words)
# # # # # # # # # print('Original text: ' + text)
# # # # # # # # # print('Expanded_text: ' + expanded_text)


# # # # # # # # import re

# # # # # # # # def remove_special_characters_except_space(text):
# # # # # # # #     # Replace all non-alphanumeric characters (except space) with an empty string
# # # # # # # #     return re.sub(r'[^a-zA-Z0-9\s]', '', text)

# # # # # # # # # Example usage:
# # # # # # # # input_text = "hello? there A-Z-R_T(,**), world, welcome to python. this **should? the next line#followed- by@ an#other %million^ %%like $this."
# # # # # # # # cleaned_text = remove_special_characters_except_space(input_text)
# # # # # # # # print(cleaned_text)

# # # # # # # import nltk
# # # # # # # from nltk.stem import WordNetLemmatizer

# # # # # # # # nltk.download('wordnet')  # Download WordNet data

# # # # # # # wnl = WordNetLemmatizer()

# # # # # # # # Example 1: Lemmatize individual words
# # # # # # # words = ['kites', 'babies', 'dogs', 'flying', 'smiling', 'driving', 'died', 'tried', 'feet']
# # # # # # # # for word in words:
# # # # # # #     # print(f"{word} ---> {wnl.lemmatize(word)}")

# # # # # # # # Example 2: Lemmatize a sentence
# # # # # # # sentence = 'the cat is sitting with the bats on the striped mat under many flying geese'
# # # # # # # tokens = nltk.word_tokenize(sentence)
# # # # # # # lemmatized_sentence = ' '.join(wnl.lemmatize(token) for token in tokens)
# # # # # # # print(lemmatized_sentence)

# # # # # # import pandas as pd

# # # # # # data = {
# # # # # #     "A": ["TeamA", "TeamB", "TeamB", "TeamC", "TeamC", "TeamA", "TeamA"],
# # # # # #     "B": [50, 40, 40, 30, 50, 60, 50],
# # # # # #     "C": [True, False, False, False, False, True, False]
# # # # # # }

# # # # # # df = pd.DataFrame(data)

# # # # # # print(df)

# # # # # # # # df["some experimental shit"] = df.apply(lambda x : True if x["B"] <= 40 else False, axis = 1)
# # # # # # # df.drop(0,axis=0,inplace=True)
# # # # # # # # print(df.groupby("overall").size())
# # # # # # # print(df)

# # # # # # brandwiseReviews = df.groupby(['A', 'B']).size()
# # # # # # # print(69)
# # # # # # print(brandwiseReviews)
# # # # # # x = brandwiseReviews.sort_values()
# # # # # # print(x["TeamA"].sort_values(ascending = False).index[0])
# # # # # # # print(x)
# # # # # # # print(x[-1::-1])
# # # # # # # print(69)
# # # # # # # print(brandwiseReviews)

# # # # # from datetime import datetime
# # # # # import numpy

# # # # # x = numpy.int64(1424563200)
# # # # # print(type(x))
# # # # # dt_object = datetime.fromtimestamp( x)

# # # # # print(dt_object)

# # # # # print(type(dt_object.year))

# # # # # import pandas as pd

# # # # # x = ["TeamA", "TeamB", "TeamB", "TeamC", "TeamC", "TeamA", "TeamA"]

# # # # # data = {
# # # # #     "A": ["TeamA", "TeamB", "TeamB", "TeamC", "TeamC", "TeamA", "TeamA"],
# # # # #     "B": [50, 40, 40, 30, 50, 60, 50],
# # # # #     "C": [True, False, False, False, False, True, False]
# # # # # }

# # # # # df = pd.DataFrame(data)
# # # # # # y = df.groupby(["A"])
# # # # # # print(y)
# # # # # # print(type(y))

# # # # # for i in df.iterrows():
# # # # #     print(type(i))
# # # # #     print(69)
# # # # #     print(i[0])
# # # # #     print(69)
# # # # #     print(i[1][])
# # # # #     break
# # # # import matplotlib.pyplot as plt
# # # # from wordcloud import WordCloud

# # # # # text = x

# # # # text = "screw you idiot, screw your mom, screw your dad, get burnt, get tortured in life, not really tho, just kidding"

# # # # # # Create and generate a word cloud image:
# # # # wordcloud = WordCloud().generate(text)

# # # # # # Display the generated image:
# # # # plt.imshow(wordcloud, interpolation='bilinear')
# # # # plt.axis("off")
# # # # plt.show()
# # # # print(type(wordcloud.words_))


# # # import matplotlib.pyplot as plt
# # # import numpy as np

# # # y = np.array([100, 100])

# # # plt.pie(y)
# # # plt.show() 

# # import matplotlib.pyplot as plt
# # import numpy as np

# # y = np.array([35, 25, 25, 15])
# # mylabels = [f"{i}" for i in range(4)]

# # plt.pie(y, labels = mylabels)
# # plt.show()

# import pickle
# from sklearn.feature_extraction.text import TfidfVectorizer


# # X_tfidf contains the TF-IDF representation of the sentences

# with open("headphones.pickle", "rb") as file:
#     headphones = pickle.load(file)

# with open("meta_headphones.pickle", "rb") as file:
#     meta_headphones = pickle.load(file)

# with open("meta_asin_index.pickle", "rb") as file:
#     meta_asin_index = pickle.load(file)

# headphones["actualReviewText"] = headphones.apply(lambda x : ' '.join(x["reviewText"]), axis = 1)

# print(headphones.actualReviewText)
# # Create a TfidfVectorizer
# tfidf_vectorizer = TfidfVectorizer()

# # Fit and transform the sentences
# X_tfidf = tfidf_vectorizer.fit_transform(headphones.actualReviewText)

# print(X_tfidf)
# # print(tfidf_vectorizer.get_feature_names_out()[len(tfidf_vectorizer.get_feature_names_out()) // 2])
# print(type(X_tfidf))

# word_index = {}

# for i, word in enumerate(tfidf_vectorizer.get_feature_names_out()):
#     word_index[word] = i

# # print(tfidf_vectorizer.get_feature_names_out()[70467])
# print(X_tfidf[411146, word_index["half"]])

# from sklearn.metrics import precision_recall_fscore_support
# y_pred = kmeans_model.predict(X_test)
# precision, recall, f1_score, support = precision_recall_fscore_support(y_test, y_pred, average='weighted')

import pandas as pd

data = {
    "A": ["TeamA", "TeamB", "TeamB", "TeamC", "TeamC", "TeamA", "TeamA"],
    "B": [50, 40, 40, 30, 50, 60, 50],
    "C": [True, False, False, False, False, True, False]
}

df = pd.DataFrame(data)

print(df['A'].unique())